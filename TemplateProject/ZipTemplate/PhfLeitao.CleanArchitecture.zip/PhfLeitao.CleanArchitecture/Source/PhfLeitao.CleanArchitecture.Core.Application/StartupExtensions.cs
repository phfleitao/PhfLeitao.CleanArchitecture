﻿namespace AspNetCoreWebApiCleanArchitecture.WebApi.Extensions
{
    public static class StartupExtensions
    {
        #region Configure Services
        #endregion

        #region Configure (Application)
        #endregion
    }
}
