﻿namespace $safeprojectname$.DomainObjects
{
    public interface IAggregateRoot { }
}
