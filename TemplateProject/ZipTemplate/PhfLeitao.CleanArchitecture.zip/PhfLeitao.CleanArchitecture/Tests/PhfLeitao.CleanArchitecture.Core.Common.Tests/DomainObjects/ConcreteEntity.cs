﻿using $ext_safeprojectname$.Core.Common.DomainObjects;
using System;

namespace $safeprojectname$.DomainObjects
{ 
    public class ConcreteEntity : Entity<Guid>
    {
        public ConcreteEntity() : base(Guid.NewGuid()) { }
        public ConcreteEntity(Guid id) : base(id) { }
        public override bool IsValid()
        {
            return true;
        }
    }
}
